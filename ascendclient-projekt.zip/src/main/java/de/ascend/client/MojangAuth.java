package de.ascend.client;

import com.mojang.authlib.minecraft.MinecraftSessionService;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.lang.reflect.Field;
import java.util.UUID;

/**
 * Beweist dem Backend die Identität über den Mojang-Sessionserver (wie beim Server-Login):
 * Der Client meldet "joinServer(serverId)", das Backend prüft per hasJoined. Es wird nur ein
 * einmaliges Zufallstoken (serverId) an das Backend gesendet – nie das Access-Token.
 *
 * Der Sessionservice wird per Reflection über den Typ (authlib) gesucht, weil sein Zugriffsweg
 * zwischen Minecraft-Versionen wechselt. So bleibt die Mod versionsrobust.
 */
final class MojangAuth {
    private MojangAuth() {}

    /** @return null bei Erfolg, sonst Fehlertext */
    static String join(String serverId) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            Session session = mc.getSession();
            UUID uuid = session.getUuidOrNull();
            if (uuid == null) return "Keine gültige Minecraft-Sitzung (Offline-Konto?).";
            MinecraftSessionService service = findService(mc);
            if (service == null) return "Sitzungsdienst nicht gefunden (Minecraft-Version?).";
            service.joinServer(uuid, session.getAccessToken(), serverId);
            return null;
        } catch (Exception e) {
            return "Identitätsprüfung fehlgeschlagen: " + e.getClass().getSimpleName();
        }
    }

    private static MinecraftSessionService findService(Object root) throws Exception {
        MinecraftSessionService direct = fieldOfType(root);
        if (direct != null) return direct;
        for (Field f : root.getClass().getDeclaredFields()) {
            Class<?> t = f.getType();
            if (t.isPrimitive() || t.getName().startsWith("java.")) continue;
            f.setAccessible(true);
            Object child = f.get(root);
            if (child == null || child == root) continue;
            MinecraftSessionService s = fieldOfType(child);
            if (s != null) return s;
        }
        return null;
    }

    private static MinecraftSessionService fieldOfType(Object o) throws Exception {
        for (Field f : o.getClass().getDeclaredFields()) {
            if (MinecraftSessionService.class.isAssignableFrom(f.getType())) {
                f.setAccessible(true);
                Object v = f.get(o);
                if (v != null) return (MinecraftSessionService) v;
            }
        }
        return null;
    }
}
