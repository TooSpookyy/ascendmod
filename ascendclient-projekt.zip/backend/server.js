// ASCEND Stream-Backend – keine Abhängigkeiten, nur Node.js >= 18.
// Start:  node server.js      (hinter einem HTTPS-Reverse-Proxy betreiben, z. B. Caddy/nginx)
//
// Identität: Der Mod-Client ruft GET /challenge ab, meldet die serverId per Mojang joinServer
// und sendet sie mit. Das Backend prüft über sessionserver.mojang.com/hasJoined, dass der
// Spielername wirklich zu diesem Spieler gehört. Niemand kann einen fremden Eintrag überschreiben.
//
// Umgebungsvariablen:
//   PORT            (Standard 8080)
//   DATA_FILE       (Standard ./streams.json)
//   ALLOWED_PLAYERS Komma-getrennte Liste der Clan-Spielernamen (leer = alle mit gültigem Account)

const http = require('http');
const https = require('https');
const fs = require('fs');
const crypto = require('crypto');

const PORT = parseInt(process.env.PORT || '8080', 10);
const DATA_FILE = process.env.DATA_FILE || './streams.json';
const ALLOWED = (process.env.ALLOWED_PLAYERS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);

const NAME_RE = /^[A-Za-z0-9_]{3,16}$/;
const TWITCH_PATH = /^\/[A-Za-z0-9_]{3,25}$/;
const YT_PATH = /^\/(watch|live\/[A-Za-z0-9_-]{6,20}|@[A-Za-z0-9_.-]{2,40}(\/live|\/streams)?|channel\/[A-Za-z0-9_-]{10,40}(\/live)?)$/;

let streams = {};
try { streams = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { streams = {}; }
const save = () => fs.writeFileSync(DATA_FILE, JSON.stringify(streams, null, 2));

// ---- Challenges (einmalig, 2 Minuten gültig)
const challenges = new Map();
setInterval(() => { const now = Date.now(); for (const [k, v] of challenges) if (now - v > 120000) challenges.delete(k); }, 30000).unref();

// ---- Rate limit je IP
const hits = new Map();
function limited(ip, max = 30, windowMs = 60000) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter(t => now - t < windowMs);
  arr.push(now); hits.set(ip, arr);
  return arr.length > max;
}
setInterval(() => hits.clear(), 600000).unref();

function validateUrl(input) {
  if (typeof input !== 'string' || input.length > 200) return null;
  let u; try { u = new URL(input); } catch { return null; }
  if (u.protocol !== 'https:' || u.username || u.password || u.port) return null;
  const h = u.hostname.toLowerCase();
  if (h === 'twitch.tv' || h === 'www.twitch.tv') {
    if (!TWITCH_PATH.test(u.pathname)) return null;
    return { platform: 'Twitch', url: 'https://www.twitch.tv' + u.pathname };
  }
  if (h === 'youtube.com' || h === 'www.youtube.com' || h === 'm.youtube.com') {
    if (!YT_PATH.test(u.pathname) || u.search.length > 60) return null;
    return { platform: 'YouTube', url: 'https://www.youtube.com' + u.pathname + u.search };
  }
  if (h === 'youtu.be' && /^\/[A-Za-z0-9_-]{6,20}$/.test(u.pathname)) return { platform: 'YouTube', url: 'https://youtu.be' + u.pathname };
  return null;
}

function hasJoined(name, serverId) {
  return new Promise(resolve => {
    const url = `https://sessionserver.mojang.com/session/minecraft/hasJoined?username=${encodeURIComponent(name)}&serverId=${encodeURIComponent(serverId)}`;
    https.get(url, { timeout: 6000 }, res => {
      let body = ''; res.on('data', d => { if (body.length < 4096) body += d; });
      res.on('end', () => {
        try { const j = JSON.parse(body); resolve(res.statusCode === 200 && j.name && j.name.toLowerCase() === name.toLowerCase()); }
        catch { resolve(false); }
      });
    }).on('error', () => resolve(false)).on('timeout', function () { this.destroy(); resolve(false); });
  });
}

function send(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'X-Content-Type-Options': 'nosniff' });
  res.end(JSON.stringify(obj));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let b = ''; req.on('data', d => { b += d; if (b.length > 4096) { reject(new Error('zu groß')); req.destroy(); } });
    req.on('end', () => { try { resolve(JSON.parse(b)); } catch { reject(new Error('kein JSON')); } });
  });
}

async function authenticate(body) {
  const { player, serverId } = body || {};
  if (typeof player !== 'string' || !NAME_RE.test(player)) return 'Ungültiger Spielername.';
  if (typeof serverId !== 'string' || !challenges.has(serverId)) return 'Challenge ungültig oder abgelaufen.';
  challenges.delete(serverId);                      // einmalig
  if (ALLOWED.length && !ALLOWED.includes(player.toLowerCase())) return 'Spieler ist nicht für den Clan freigeschaltet.';
  if (!(await hasJoined(player, serverId))) return 'Identität konnte nicht bestätigt werden.';
  return null;
}

http.createServer(async (req, res) => {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
  if (limited(ip)) return send(res, 429, { error: 'Zu viele Anfragen.' });
  try {
    if (req.method === 'GET' && req.url === '/streams') {
      return send(res, 200, Object.entries(streams).map(([player, s]) => ({ player, platform: s.platform, url: s.url, updated: s.updated })));
    }
    if (req.method === 'GET' && req.url === '/challenge') {
      if (challenges.size > 5000) return send(res, 503, { error: 'Überlastet.' });
      const serverId = crypto.randomBytes(12).toString('hex');
      challenges.set(serverId, Date.now());
      return send(res, 200, { serverId });
    }
    if (req.method === 'POST' && (req.url === '/streams' || req.url === '/streams/delete')) {
      const body = await readBody(req);
      const err = await authenticate(body);
      if (err) return send(res, 403, { error: err });
      if (req.url === '/streams/delete') {
        delete streams[body.player]; save();
        return send(res, 200, { ok: true });
      }
      const v = validateUrl(body.url);
      if (!v) return send(res, 400, { error: 'Nur gültige HTTPS-Links zu Twitch oder YouTube.' });
      if (!streams[body.player] && Object.keys(streams).length >= 200) return send(res, 507, { error: 'Liste voll.' });
      streams[body.player] = { platform: v.platform, url: v.url, updated: new Date().toISOString() };
      save();
      return send(res, 200, { ok: true });
    }
    send(res, 404, { error: 'Nicht gefunden.' });
  } catch (e) {
    send(res, 400, { error: 'Ungültige Anfrage.' });
  }
}).listen(PORT, () => console.log('ASCEND Stream-Backend auf Port ' + PORT));
